# Aetheria Chronicles

RPG fantasi orisinal berbasis browser, terinspirasi mekanik MMORPG. Mainkan petualangan solo dengan ilustrasi dunia dan boss lokal, tanpa instalasi package atau koneksi ke layanan eksternal.

## Menjalankan

Ekstrak seluruh ZIP, lalu jalankan server lokal dengan salah satu cara berikut.

Untuk autosave dengan alamat yang konsisten, gunakan server lokal:

- **Windows:** instal Python 3, lalu klik dua kali `MULAI-WINDOWS.bat`.
- **macOS / Linux:** dari folder game jalankan `python3 jalankan.py`.

Browser terbuka otomatis pada `http://127.0.0.1:8000/`. Biarkan terminal terbuka selama bermain; tekan Ctrl+C untuk berhenti. Jika port terpakai, gunakan `python3 jalankan.py --port 8001` (Windows: `py -3 jalankan.py --port 8001`).

Tidak ada proses build atau package tambahan. Sebagai alternatif, `index.html` dapat dibuka langsung jika browser mengizinkan file lokal; penyimpanan progres dari file lokal bisa berbeda antarbrowser. Petunjuk lengkap tersedia di `PANDUAN.txt`.

## Fitur

- Tiga wilayah petualangan dengan batas level, EXP, Zeny, dan material.
- Enam equipment terpasang dengan stat yang memengaruhi combat power.
- Refinement hingga +15, peluang sukses, biaya material, serta Protection Stone.
- Tiga MVP dengan pertarungan berbasis giliran, cooldown skill, critical hit, healing, potion, dan reward.
- Quest harian yang direset setiap hari UTC dan achievement dengan hadiah sekali klaim.
- Merchant, welcome mail, kontribusi guild companion, dan peringkat lokal.
- Nama karakter yang bisa diubah, ekspor save, reset progres, dan autosave di `localStorage`.
- Tampilan responsif, navigasi keyboard, dan dukungan reduced motion.

Mulai dari **Adventure** untuk mengumpulkan bekal, buka **Refinement** untuk meningkatkan equipment, lalu tantang **Verdant Warden** di **MVP Hunt**. Ambil reward melalui **Quest Log** dan surat di bagian atas layar.

Progres tersimpan per browser pada key `aetheria-save-v1`. Gunakan browser dan alamat (termasuk port) yang sama untuk melanjutkan. Ekspor save lewat profil sebelum menghapus data browser; ekspor menyediakan backup JSON dan belum dilengkapi fitur impor. Guild dan peringkat menggunakan companion NPC lokal; game ini tidak menggunakan server multiplayer.

## Validasi

```sh
node --check engine.js
node --check script.js
node tests/engine.test.cjs
node tests/daily.test.cjs
```

Engine dapat diuji menggunakan penyimpanan, waktu, dan random number generator yang diinjeksi. Pengujian browser saat pengembangan memverifikasi eksplorasi, quest, achievement, refine, pembelian, mail, combat MVP, mundur, guild, persistensi progres, dan navigasi ponsel.

## Struktur

- `index.html` — kerangka aplikasi.
- `styles.css` — layout, tema, dan komponen responsif.
- `engine.js` — state, aturan game, dan penyimpanan.
- `script.js` — tampilan, navigasi, dialog, dan interaksi.
- `assets/` — ilustrasi dunia, boss, dan equipment orisinal.
